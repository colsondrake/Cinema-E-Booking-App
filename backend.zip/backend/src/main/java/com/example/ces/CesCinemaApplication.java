package com.example.ces;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CesCinemaApplication {
    public static void main(String[] args) {
        SpringApplication.run(CesCinemaApplication.class, args);
    }
}